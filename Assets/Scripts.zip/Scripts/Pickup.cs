using UnityEngine;
public class Pickup : MonoBehaviour
{
    public float time;
    void OnTriggerEnter2D(Collider2D collision)
    {
        //Debug.Log("pp");
        if (collision.CompareTag("Player"))
        {
            Destroy(gameObject);

            if (collision.TryGetComponent(out Player component))
	        {
		        component.increaseXP(1);
	        }
        }
    }
}

