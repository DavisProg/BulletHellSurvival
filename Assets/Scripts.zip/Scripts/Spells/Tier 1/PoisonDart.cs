using UnityEngine;

public class PoisonDart : BaseSpell
{
    [SerializeField] GameObject projectilePrefab;
    [SerializeField] LayerMask enemyLayer;
    [SerializeField] float damage;
    [SerializeField] float size;
    [SerializeField] float speed;
    [SerializeField] int pierce;
    [SerializeField] float damagePerInterval;
    [SerializeField] float damageDuration;
    [SerializeField] int amount;
    [SerializeField] float projectileLifeTime;

    void Awake()
    {
        defineCast();
        setTrigger(new onLoop(this, cooldown));
    }
    public override void defineCast()
    {
        targeting = new NearestTarget(enemyLayer, amount);
        casting = new CastProjectile(
            projectilePrefab,
            speed,
            pierce,
            size,
            projectileLifeTime,
            new DamageOverTimeEffect(damage, damagePerInterval, damageDuration, this)
        );
    }
    public override void firstPathEnable()
    {
        damage = 10;
        defineCast();
    }
    public override void secondPathEnable()
    {
        pierce = 3;
        defineCast();
    }
}
