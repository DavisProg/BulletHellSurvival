using UnityEngine;

public class Tank : BaseSpell
{
    [SerializeField] GameObject turretPrefab;
    [SerializeField] float damage;
    [SerializeField] float size;
    [SerializeField] float interval;
    [SerializeField] float duration;

    void Awake()
    {
        defineCast();
        setTrigger(new onLoop(this, cooldown));
    }
    public override void tryCast()
    {
        if (level > 0)
        {
            while (true)
            {
                if(targeting.GetTarget(transform, range, out Vector2[] target)){
                    bool completedSuccesfully = true;
                    foreach(Vector2 targetPos in target)
                    {
                        if (Vector2.Distance(targetPos, gameObject.transform.position) <= 5)
                        {
                            completedSuccesfully = false;
                            break;
                        }
                        casting.Cast(transform, targetPos);
                    }
                    if (completedSuccesfully)
                    {
                        break;
                    }
                }
            }
        }
    }
    public override void defineCast()
    {
        targeting = new RandomPoint();
        casting = new CastTurret(
            turretPrefab,
            duration,
            damage,
            interval,
            size
        );
    }
    public override void firstPathEnable()
    {
        cooldown = 5;
        defineCast();
    }
    public override void secondPathEnable()
    {
        damage = 150;
        defineCast();
    }
}
